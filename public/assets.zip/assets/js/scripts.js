// get copyright year
const d = new Date();
let year = d.getFullYear();
document.getElementById("year").innerHTML = year;